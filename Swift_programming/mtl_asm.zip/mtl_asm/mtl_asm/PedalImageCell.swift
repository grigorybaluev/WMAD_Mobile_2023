//
//  PedalImageCell.swift
//  mtl_asm
//
//  Created by MacBook on 14.06.2023.
//

import UIKit

class PedalImageCell: UITableViewCell {
  
  @IBOutlet weak var pedalCellImage: UIImageView!
  
}
