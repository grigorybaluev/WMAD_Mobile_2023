import XCTest

import FinalExamV2Tests

var tests = [XCTestCaseEntry]()
tests += FinalExamV2Tests.allTests()
XCTMain(tests)
