#import "Question.h"

@interface DivisionQuestion : Question

@end
