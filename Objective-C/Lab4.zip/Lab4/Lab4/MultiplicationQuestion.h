#import "Question.h"

@interface MultiplicationQuestion : Question

@end
