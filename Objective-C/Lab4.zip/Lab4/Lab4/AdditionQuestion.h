#import "Question.h"

@interface AdditionQuestion : Question

@end
