#import "Question.h"

@interface SubtractionQuestion : Question

@end
