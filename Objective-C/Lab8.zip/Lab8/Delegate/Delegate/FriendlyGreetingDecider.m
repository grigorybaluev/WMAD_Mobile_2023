//
//  FriendlyGreetingDecider.m
//  Delegate
//
//  Created by MacBook on 15.09.2023.
//

#import "FriendlyGreetingDecider.h"

@implementation FriendlyGreetingDecider

- (BOOL)shouldSayHello {
  return YES;
}

@end
