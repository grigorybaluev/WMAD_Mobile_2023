//
//  AngryGreetingDecider.m
//  Delegate
//
//  Created by MacBook on 15.09.2023.
//

#import "AngryGreeterDecider.h"

@implementation AngryGreeterDecider

- (BOOL)shouldSayHello {
  return NO;
}

@end
