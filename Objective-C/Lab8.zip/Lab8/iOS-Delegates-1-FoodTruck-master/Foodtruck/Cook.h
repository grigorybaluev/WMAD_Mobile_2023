//
//  Cook.h
//  Foodtruck
//
//  Created by MacBook on 15.09.2023.
//  Copyright © 2023 Lighthouse Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Cook<FoodTruckDelegate> : NSObject

@end

NS_ASSUME_NONNULL_END
