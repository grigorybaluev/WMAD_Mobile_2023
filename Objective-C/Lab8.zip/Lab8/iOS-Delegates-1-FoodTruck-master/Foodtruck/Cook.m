//
//  Cook.m
//  Foodtruck
//
//  Created by MacBook on 15.09.2023.
//  Copyright © 2023 Lighthouse Labs. All rights reserved.
//

#import "Cook.h"
#import "FoodTruck.h"

@implementation Cook

-(double)foodTruck:(FoodTruck *)truck priceForFood:(NSString *)food {
  return 2.0;
}

@end
